# SJPortal
Journal Portal
