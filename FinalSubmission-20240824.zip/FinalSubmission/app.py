from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory
import os
from werkzeug.utils import secure_filename
from flask_sqlalchemy import SQLAlchemy

basedir = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)
app.secret_key = "secret_key"
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'instance', 'database.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Model for storing document information
class Document(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100))
    filename = db.Column(db.String(100))
    review = db.Column(db.String(500), nullable=True)

# Route for home page
@app.route('/')
def index():
    documents = Document.query.all()
    return render_template('index.html', documents=documents)

# Route for uploading documents
@app.route('/upload', methods=['POST'])
def upload():
    title = request.form['title']
    file = request.files['file']
    if file:
        filename = secure_filename(file.filename)
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        new_doc = Document(title=title, filename=filename)
        db.session.add(new_doc)
        db.session.commit()
        flash('Document uploaded successfully!')
        return redirect(url_for('index'))
    flash('Failed to upload document.')
    return redirect(url_for('index'))

# Route for reviewing documents
@app.route('/review/<int:id>', methods=['GET', 'POST'])
def review(id):
    document = Document.query.get_or_404(id)
    if request.method == 'POST':
        document.review = request.form['review']
        db.session.commit()
        flash('Review saved successfully!')
        return redirect(url_for('index'))
    return render_template('review.html', document=document)

# Route for downloading documents
@app.route('/download/<filename>')
def download(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__ == '__main__':
    # Ensure the 'instance' and 'uploads' directories exist
    if not os.path.exists('instance'):
        os.makedirs('instance')
    if not os.path.exists('uploads'):
        os.makedirs('uploads')

    # Create database tables within the application context
    with app.app_context():
        db.create_all()

    app.run(debug=True)
